from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class PatientData(BaseModel):
    chief_complaint: str
    age: int
    sbp: int
    dbp: int
    hr: int
    rr: int
    bt: float
    mental: str
    sex: str
    arrival_mode: str
    injury: str
    pain: int

def ktas_risk_ve_sebep(data: PatientData):
    risk_sebepleri = []

    if data.bt > 38:
        risk_sebepleri.append("Yüksek ateş (>38°C)")
    if data.hr > 100:
        risk_sebepleri.append("Yüksek nabız (>100 bpm)")
    if data.age > 70:
        risk_sebepleri.append("Yaşın 70'in üzerinde olması")
    if data.sbp < 90:
        risk_sebepleri.append("Düşük sistolik kan basıncı (<90 mmHg)")
    if data.dbp < 60:
        risk_sebepleri.append("Düşük diyastolik kan basıncı (<60 mmHg)")
    if data.rr > 30:
        risk_sebepleri.append("Aşırı hızlı solunum (>30/dk)")
    if data.mental.lower() != "uyanık":
        risk_sebepleri.append("Bilinç durumunun uyanık olmaması")
    if data.pain >= 8:
        risk_sebepleri.append("Şiddetli ağrı (8 ve üzeri)")

    if risk_sebepleri:
        return "Kırmızı", "Aşağıdaki sebepler nedeniyle yüksek risk:\n- " + "\n- ".join(risk_sebepleri)

    orta_risk_sebepleri = []
    if 5 <= data.pain < 8:
        orta_risk_sebepleri.append("Orta şiddette ağrı (5-7 arası)")
    if 90 <= data.sbp < 100:
        orta_risk_sebepleri.append("Sistolik kan basıncı sınırda düşük (90-99 mmHg)")
    if 60 <= data.dbp < 70:
        orta_risk_sebepleri.append("Diyastolik basınç sınırda düşük (60-69 mmHg)")
    if 21 <= data.rr <= 30:
        orta_risk_sebepleri.append("Solunum sayısının yüksek olması (21-30/dk)")
    if 37.5 <= data.bt <= 38:
        orta_risk_sebepleri.append("Hafif ateş (37.5-38°C)")

    if orta_risk_sebepleri:
        return "Sarı", "Aşağıdaki sebepler nedeniyle orta risk:\n- " + "\n- ".join(orta_risk_sebepleri)

    return "Yeşil", "Hayati bulgular normal ve ağrı düşük, düşük risk."


@app.post("/predict")
def predict(data: PatientData):
    risk, sebep = ktas_risk_ve_sebep(data)
    return {
        "ktas_tahmini": risk,
        "risk_sebebi": sebep,
        "chief_complaint": data.chief_complaint
    }
