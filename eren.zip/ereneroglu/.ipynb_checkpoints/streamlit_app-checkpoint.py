import streamlit as st
import requests

st.title("🏥 Acil Servis Triyaj Sistemi")

# Giriş alanları
chief_complaint = st.text_input("Hasta Şikayeti (Chief Complaint)")
age = st.number_input("Yaş", min_value=0, max_value=120, step=1)
sbp = st.number_input("Sistolik Kan Basıncı (SBP)", min_value=0)
dbp = st.number_input("Diyastolik Kan Basıncı (DBP)", min_value=0)
hr = st.number_input("Nabız (HR)", min_value=0)
rr = st.number_input("Solunum Hızı (RR)", min_value=0)
bt = st.number_input("Vücut Isısı (BT)", min_value=30.0, max_value=45.0, format="%.1f")
mental = st.selectbox("Bilinç Durumu", ["Uyanık", "Yorgun", "Tepkisiz"])
sex = st.selectbox("Cinsiyet", ["Erkek", "Kadın"])
arrival_mode = st.selectbox("Hastanın Geliş Şekli", ["Ambulans", "Yürüyerek", "Sedye ile"])
injury = st.selectbox("Travma Durumu", ["Evet", "Hayır"])
pain = st.slider("Ağrı Puanı (0-10)", 0, 10, step=1)

# Buton
if st.button("Tahmin Yap"):
    if not chief_complaint:
        st.error("Lütfen hasta şikayetini girin.")
    else:
        input_data = {
            "chief_complaint": chief_complaint,
            "age": age,
            "sbp": sbp,
            "dbp": dbp,
            "hr": hr,
            "rr": rr,
            "bt": float(bt),
            "mental": mental,
            "sex": sex,
            "arrival_mode": arrival_mode,
            "injury": injury,
            "pain": pain
        }

        try:
            response = requests.post("http://127.0.0.1:8000/predict", json=input_data)
            response.raise_for_status()
            result = response.json()

            # Görüntüleme
            st.subheader("📝 Hasta Şikayeti")
            st.write(result["chief_complaint"])

            st.subheader("🏷️ Tahmini KTAS Seviyesi")
            if result["ktas_tahmini"] == "Kırmızı":
                st.error(f"🚨 {result['ktas_tahmini']}")
            elif result["ktas_tahmini"] == "Sarı":
                st.warning(f"⚠️ {result['ktas_tahmini']}")
            else:
                st.success(f"✅ {result['ktas_tahmini']}")

            st.subheader("🔍 Risk Sebepleri")
            st.write(result["risk_sebebi"])

        except Exception as e:
            st.error(f"API bağlantı hatası: {e}")
